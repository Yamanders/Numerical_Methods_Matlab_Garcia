% Molling, Amanda Hw#2 Problem #4 9/19/2012


%% A function

% function yi = hw2_4b(xi,x,y)
% clear all; help hw2_4

%Function to interpolate between data points using Lagrange polynomial
%Inputs:
%x-Vector of x coordinates of data points (3 dimensionsional)
%y - Vector of y coordinates of data points (3D)
%Outputs:
%yi - The interpolation polynomial evaluated at xi

% Calculate yi = p(xi) using Lagrange polynomial
clear all; clc;
x=input('Enter the x coordinates as a vector [xi xii...xn]');
y=input('Enter the y coordinates as a vector [yi yii...yn]');
xi=input('Enter the point xi at which to evaluate the Lagrange Polynomial: (x=?)');
       n = max(size(x));
       yi=0;
       
      
    if isequal(size(x), size(y));
     
         for w = 1:n;
             Numerator1=y(w); %Initializes the variables
            denominator=1;  
             for j = 1:n;
                 if j ~= w; %For j isn't not equal to w                                         
                      Numerator1=Numerator1*(xi-x(j)); %Multiplies the previous numerator by the term (xi-xj)
                      denominator=denominator*(x(w)-x(j));
%                     yiloop=totalNumerator1/denominator
%                      k=j %Makes an index that is dependent on the previous j 
%                     numerator=(xi-x((n-1))); %Creates an array of xi-xj
%                     topyi = y(n)*prod(numerator); % Multiplies every term in the array together with yj
%                     denominator=(x(w)-x(w));
                 end            
             end
             yi=yi+Numerator1/denominator; %Adds each part
         end
         disp('The yi approximation is: ')
         disp(yi)
    else
    
    disp('Your vectors should both have the same dimensions. Please try')
    disp('the program again.')

    end
return; % End of function