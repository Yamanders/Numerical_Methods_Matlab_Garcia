%Amanda Molling HW#2 Problem#1 September 18, 2012
%Press enter to continue on between parts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% The Sumpi (Part A)

clear all
clc
format rat
help hw2_1f
disp('Part A')
%Converts the terms to fraction to more easily check for accuracy.
% I will use 4 times the summation of ((-1)^i)/(2i+1) from 0 to n to
% calculate this approximation of pi
tic
n=0:1001;
    partpi=((-1).^(n))./(2.*n+1); % Creates the individual terms
format long   % Puts the format back into decimal form
    
    disp('The first approximation for pi is:') 
    Sumpi = 4.*(sum((partpi))); %Adds all of the terms together 
    disp(Sumpi)
    
   toc
%tElapsed1=toc
disp('Press enter to go next part')
pause
    
%% The second version
disp('Part B')
disp('This is the second evaluation. The positive and negative terms are')
disp('generated separately and then added together.')
format rat % This format made checking the formula useful as the formula is 
%in fractional notation as opposed to decimal.

% I will do all positive values and then all negative values. 
% This will be 4*[summation of (1/(i+1)) - summation 1/(2j+1)
tic
i = 0:2:1000;
j=1:2:1001;

partpii = (1./(2.*i+1)); %Does the positive terms  
partpij = (1./(2.*j+1)); %Creates the negative terms

format long % Converts the number to a decimal to view pi

Sumpi2=4.*(sum((partpii)-(partpij))); % Adds the positive and negative terms
disp('The second approximatin for pi is:')
disp(Sumpi2)


tElapsed2=toc 

disp('Press enter to go next part')
pause
%% Creating a for loop to run each of them 1000 times.
clear all; clc
disp('Part C')
m=1:1000; % Defines the number of times pi will be calculated
% Also defines the size of the array of the times
elapsedTimeMatrix = zeros(max(size(m)),1);    
for p=1:max(size(m)) 
    tic
n=0:10000; % Number of terms that will be used to calcuate pi
%tic
    partpi=((-1).^(n))./(2.*n+1); %% Calculates an array of things to be summed
format long    
    
    Sumpi = 4.*(sum((partpi))); %Multiplies the pi/4 equation by 4 and adds
    %the terms together.
    
elapsedTimeMatrix(p,1) = toc; % Fills each term of the time array respectively
end
disp('The first approximation for pi is:')
disp(double(Sumpi))
elapsedTimeMatrixMeanA= mean(elapsedTimeMatrix)
elapsedTimeMatrixStandardDeviationA=std(elapsedTimeMatrix)

%elasedTimeMatrixMean = (sum(elapsedTimeMatrix))/max(size(elapsedTimeMatrix))
%This does the exact same thing
disp('Press enter to go next part')
pause;

%% The method b time testing

m=1:1000; % Defines the number of times pi will be calculated
% Also defines the size of the array of the times
elapsedTimeMatrix = zeros(max(size(m)),1);
for p=1:max(size(m))
    tic
    
    i = 0:2:10000;
    j=1:2:10001;
    
    partpii = (1./(2.*i+1)); %Does the positive terms
    partpij = (1./(2.*j+1)); %Creates the negative terms
    
    format long % Converts the number to a decimal to view pi
    
    Sumpi2=4.*(sum((partpii)-(partpij))); % Adds the positive and negative terms

elapsedTimeMatrix(p,1) = toc; % Fills each term of the time array respectively
end
disp('The second approximation for pi is:')
disp(Sumpi2)
%double(elapsedTimeMatrix) This would display all of the times.

elapsedTimeMatrixMeanB= mean(elapsedTimeMatrix)
elapsedTimeMatrixStandardDeviationB=std(elapsedTimeMatrix)

%elasedTimeMatrixMean = (sum(elapsedTimeMatrix))/max(size(elapsedTimeMatrix))
%This does the exact same thing

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
