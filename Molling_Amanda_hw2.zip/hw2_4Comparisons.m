%% HW 2 question #2 comparisons
% The multiterm approximation for the Lagrange polynomail of the following 
% Bessel values are (Using the five given points): 
%X = [0.3 0.9 1.1 1.5 2.0]
%J_0 = [0.9776 0.8075 0.7195 0.5076 0.1854]
% 
% 
% The original function values are (using the three given points):
%X = [0.3 0.9 1.1 1.5 2.0]
%J_0 = [0.2205 0.4848 1.1131 3.1801 7.2832]
% 
%The correct values are: 
%J_0 = [0.9776 0.8075 0.7196 0.5118 0.2239]
% 
% So, more terms made the output MUCH more accurate.
% 
%
% 
% 
% 
% 
% 
% 
% 
% 
% 
