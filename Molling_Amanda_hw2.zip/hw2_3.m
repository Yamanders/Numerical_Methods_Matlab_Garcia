% Molling, Amanda 9/19/2012 HW#2 Problem#2
% orthog-Program to test if a pair of vectors is orthogonal.
%Does NOT assume all vectors are in 3D space

%% The real work


clc; clear all; help hw2_2;%Clears the memory and prints the header.

%Requests vectors a and b from the user
disp('Commas do not matter.')
a = input('Enter in the first vector in the form [ai, aii, aiii]: ');
b = input('Enter in the second vector in the form [bi, bii, biii]: ');

vectorSize=0;
if max(size(a))==3
    vectorSize =1;
end
if isequal(size(a), size(b))&&(vectorSize)
    C=cross(a,b);
    format rat
        disp('The unit orthogonal vector is:');
        Vector=C./(sqrt(sum((C.^2)))) %Normalizes the C vector
    
        %fprintf('Dot Product = %g\n',a_dot_b);
   
else
    disp('Your vectors should both have the dimensions 1x3. Please try')
    disp('the program again.')
end