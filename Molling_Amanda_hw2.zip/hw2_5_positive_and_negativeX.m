%This is a modification of the the Taylor expansion equation work for 
%negative x-value numbers. The identity e^x = 1/e^-x =1/S(-x,infinity) 
%is used to reduce amount of error occuring. The error in the graph, when x 
%was negative spiked very sharply in the middle of the set of terms instead
%of falling off naturally like the error did for positive x-values.



function h= hw2_5_positive_and_negativeX(x,N);
clear;close;clc
x = input('At which x value would you like to approximate e^x?  ');
    limSPartialsum=zeros(1,60); % defining a matrix
    errormatrix=zeros(1,60);
    disp('The error on the expansion with respect to the number of terms is graphed:');
    disp('The approximation for e^x of 60 terms is: ') 
    i = 1:60;
        limSPartial(i)=((abs(x)).^(i-1)./(factorial(i-1)));%Each term to be summed in an array
        limSPartialsum(1)=limSPartial(1); %This value is 1 so we don't haveto worry about its inverse
    for w = 1:59; %We have already found 1, so we make all our indices w+1
        if x>=0
            limSPartialsum(w+1)=limSPartialsum(w)+limSPartial(w+1);
        elseif x<0 % If x is negative, we take the inverse of the sum to find the estimated value
           limSPartialsum(w+1)=((limSPartialsum(w))^(-1)+(limSPartial(w+1)))^(-1);%array of estimations based on N
        end   
        errormatrix=(abs(limSPartialsum-exp(x)))/(exp(x));%Array of errors with respect to N    
    end
    disp(limSPartialsum(60))
    plot(i, errormatrix)%N is the independent variable; error is the dependent
          xlabel({'Number of terms'}); %Creates xlabel
          ylabel({'Error'}); %Create ylabel
          title({'Error versus number of terms for the Taylor Expansion of e^x'});%Create title
    
    
return;
%%%%%%%%%%%%%%%%%%%%%%%%CONCLUSION%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Correcting for the negative value of x causes the error to drop off 
%as quickly for negative values and for positive values.