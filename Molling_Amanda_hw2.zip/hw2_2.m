% Molling, Amanda 9/19/2012 HW#2 Problem#2
% orthog-Program to test if a pair of vectors is orthogonal.
%Does NOT assume all vectors are in 3D space

%% The real work


clc; clear all; help hw2_2;%Clears the memory and prints the header.

%Requests vectors a and b from the user
disp('Commas do not matter.')
a = input('Enter in the first vector in the form [ai, aii, aiii...an]: ');
b = input('Enter in the second vector in the form [bi, bii, biii...bn]: ');

%c = size(b);
if isequal(size(a), size(b)) 

    a_dot_b=a*b';

    if(a_dot_b)==0,
        disp('The two vectors are orthogonal.');
        else
        disp('The two vectors are NOT orthogonal.');
        %fprintf('Dot Product = %g\n',a_dot_b);
    end
else
    disp('Your vectors should have the same dimensions.')
end