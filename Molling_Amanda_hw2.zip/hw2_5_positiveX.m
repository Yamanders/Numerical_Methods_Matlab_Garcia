% This is a function to test and plot the error on the Taylor Series
% expansion at a given value of x and number of terms.

function h = hw2_5_positiveX(x,N);
clear;close
x = input('At which x value would you like to approximate e^x  ?');
N = input('How many terms would you like to sum over?  ')

 n = 1:N;
    limS=sum(x.^(n-1)./(factorial(n-1)))
    
    error=abs(limS-exp(x))/(exp(x))
    limSPartialsum=zeros(1,60); % defining a matrix
    errormatrix=zeros(1,60);
    disp('The error on the expansion with respect to the number of terms is:')
 i = 1:60;
        limSPartial(i)=(x.^(i-1)./(factorial(i-1)));
        limSPartialsum(1)=limSPartial(1);
    for w = 1:59;
           
            limSPartialsum(w+1)=limSPartialsum(w)+limSPartial(w+1);
 
    errormatrix=(abs(limSPartialsum-exp(x)))/(exp(x));
   
    end
    plot(i, errormatrix)   
          xlabel({'Number of terms'}); %Creates xlabel
          ylabel({'Error'}); %Create ylabel
          title({'Error versus number of terms for the Taylor Expansion of e^x'});%Create title
    
    
return;


