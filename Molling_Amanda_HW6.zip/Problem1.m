%Molling, Amanda 
%Numerical Methods
%HW 6 - 11/29/2012
%Problem #1 Modified dftcs for initial distribution of a intially 100
%degrees bar held at zero on the ends
%Please WAIT for the graphs to load, as they will, Matlab is just slow.


%% The diffusion equation looks like:
%d/dt(D(x,t)) = k*d^2(D(x,t))/dx^2

%The solution to this looks like:
%D(x,t) = (1/sigma(t)*2*pi)*exp(-(x-xnaught)^2/(2*sigma(t)^2))

%Our specific constants are:
%The difusion constant kappa = K /(C*rho), where K = 0.12cal/(sg deqrees C), 
%rho = 7.8g/cc, and C = 0.113 cal/(g degrees C).
clear all; clc;
help Problem1;
test=1;
if test ==1; 
    N = 70;
    tau = 0.0001;
else;
    N =input('Enter number of grid size'); %L = 50 cm
    tau=input('Enter timestep');
end;
%Defining variables/Initial variables
K=0.12; rho=7.8; C=0.113;
kappa=K/(C*rho);
L=.50; %cm
h = L/(N-1); % = L/(n-1) is the grid size over the number of grid divisions
T = zeros(N,1);
coeff = kappa*tau/(h^2);
if (tau>(1/coeff));
    disp('This is probably unstable due to timestep/coefficient ratio');
else disp('This will be stable.')
end;

%Plot variables
% y = 1:N;
xplot=((0:N-1)*h)';
Tempplot=zeros(N,1);
plotcounter=1; %iplot
tplot=1:N*tau;

for i = 2:N-1; 
    T(i) = 100;
end;
 nstep = 3000;
 nplots=100;
 plot_step=nstep/nplots;

%This is where we are going to have things happen. 
    for plotcounter = 1:nstep;
        T(1)=0;
        T(N)=0;
        T(2:(N-1))=T(2:(N-1))+(kappa*tau/(h^2))*(T(3:N)+T(1:(N-2))-2*(T(2:(N-1))));
%         T(i,1)=T(i,2);        
        %Now record the values for plotting.
         if(rem(plotcounter,plot_step)<1);
             Tempplot(:,plotcounter) = T(:) ;%Should be xplot dimensions by tplot dimensions
                tplot(plotcounter)=plotcounter*tau;
                plotcounter=plotcounter+1;
         end
    end
    figure(1); clf;
    mesh(tplot,xplot,Tempplot);
    xlabel('Time');
%     ylabel('Position');
    zlabel('Temperature(x,t)');
    title('Diffusion within iron bar');
    
    figure(2); clf; %Creates the Contour graph
    contourLevels=0:30; %contourLabels=0.5; 
    cs=contour(tplot,xplot,Tempplot,contourLevels); 
%     clabel(cs,contourLabels); 
    xlabel('Time');
    ylabel=('Position along the bar');
    title('Contour Plot');