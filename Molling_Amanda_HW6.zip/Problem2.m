% Molling, Amanda 
%Numerical Methods
%HW 6 - 11/29/2012
%Problem #2 Modified dftcs for initial distribution of a sine wave
%Please WAIT for the graphs to load, as they will, Matlab is just slow.


%The professor did not state whether the initial conditions for this
%problem included sites held at zero or not. So, the code is marked with
%the way to change this initial condition. Also, pictures of both have been
%submitted. It is exciting to see that the gaussian distribution is closely
%approximated by this method. Also, it was assumed that a half wavelength
%was requested by the professor.
%% The diffusion equation looks like:
%d/dt(D(x,t)) = k*d^2(D(x,t))/dx^2

%The solution to this looks like:
%D(x,t) = (1/sigma(t)*2*pi)*exp(-(x-xnaught)^2/(2*sigma(t)^2))

%Our specific constants are:
%The difusion constant kappa = K /(C*rho), where K = 0.12cal/(sg deqrees C), 
%rho = 7.8g/cc, and C = 0.113 cal/(g degrees C).

clear all; 
initialcondition=1; %If you want the sides held constant, leave this. 
%if you want the sides free to dissipate with everything else, change this
%value.
test=1;%Change this if you want to be able to get inputs for your values.
    if test ==1; 
        N = 80;
        tau = 0.0001;
    else;
        N =input('Enter number of grid size'); %L = 50 cm
        tau=input('Enter timestep');
    end;
%Defining variables/Initial variables
K=0.12; rho=7.8; C=0.113;
kappa=K/(C*rho);
L=.50; %cm
h = L/(N-1); % = L/(n-1) is the grid size over the number of grid divisions
coeff = kappa*tau/(h^2);
%Check for stability
    if (tau>(1/coeff));
        disp('This is probably unstable');
    else disp('This will be stable.')
    end;

%Plot variables
T = zeros(N,1);
xplot=((0:N-1)*h)';
Tempplot=zeros(N,1);
plotcounter=1; %iplot
tplot=(1:N)*tau;

for i = 1:N;  %Initial conditions
    T(i) = 15*sin(pi*xplot(i)/L); %I increased the sinusoidal amplitude by 
    %fifteen in order to have a more visually appealling graph. This does
    %not affect the dissipation ratios.
end;
 nstep = 4000;
 nplots=100;
 plot_step=nstep/nplots;
 
 %%Main loop%%
    for plotcounter = 1:nstep;
        
        T(2:(N-1))=T(2:(N-1))+(kappa*tau/(h^2))*(T(3:N)+T(1:(N-2))-2*(T(2:(N-1))));
            if initialcondition ==1
                T(1)=0;
                T(N)=0;%         
 %If you want the sides to not be held constant.
            else;
                T(1)=T(2);
                T(N)=T(N-1);
            end;

         if(rem(plotcounter,plot_step)<1);
             Tempplot(:,plotcounter) = T(:) ;%Should be xplot dimensions by tplot dimensions
                tplot(plotcounter)=plotcounter*tau;
%                 plotcounter=plotcounter+1;
         end
    end
    
    figure(1); clf; %Plot our approximated graph.
    mesh(tplot,xplot,Tempplot);
    xlabel('Time');
    ylabel('Position')
    zlabel('Temperature(x,t)');
    title('Diffusion within iron bar');
    
    figure(2); clf;%Creates Countoure graph
    contourLevels=0:0.5:10; contourLabels=0.5; 
    cs=contour(tplot,xplot,Tempplot,contourLevels); 
    clabel(cs,contourLabels); 
    xlabel('Time');
%     ylabel=('Position');
    title('Contour Plot');
    
%Creates graph of sine dissipation for comparison.
RealSine=zeros(N,max(tplot));
 RealSine((1:N),1)=sin(pi*((1:N)/L))*exp(-(pi^2)*0*kappa/(L^2));
 for t = 1:4000;    
 RealSine((1:N),t)=15*sin(pi*xplot(1:N)/L)*exp(-(pi^2)*kappa*tplot(t)/(L^2));    
 end;
 figure(3); clf;
 mesh(tplot,xplot,RealSine);
    ylabel('Position')
    zlabel('Temperature(x,t)');
    title('Diffusion within iron bar');    
    
    clc;
help Problem2;
%Check for stability
    if (tau>(1/coeff));
        disp('This is probably unstable');
    else disp('This will be stable.')
    end;