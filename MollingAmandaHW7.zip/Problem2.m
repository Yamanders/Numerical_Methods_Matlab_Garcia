% Molling, Amanda Numerical Methods
% 12/05/12 Homework 7 Problem 2
% This is for L =20. The program will do for L=100, it will just take a
% very long time. Potential is plotted in color. X,Y,Z are the axes.

%%

clear; clc; help Problem2;


% Initialize Variables;
L = 20; %Length of box; The bigger the box, the more time it takes.
V=zeros(L+1,L+1,L+1); %V(x,y,z)
Vnew=zeros(L+1,L+1,L+1);
nstep = 85;
    V(.3*L:.9*L,.5*L,.3*L:.9*L)=-10;
    V(.3*L:.9*L,.7*L,.3*L:.9*L)=10;

% Main Section
% mov=0;
%Want to use central difference method
istep =1; %This is my delta
moviecounter=1;%This is my movie counter
for timestep = 1:nstep;
 %How many iterations to do.
    for level=L/10+1:L/L:L;
        for boop = L/10+1:L/L:L;
            for zztop=L/10+1:L/L:L;
                 Vnew(boop,level,zztop)=(1/6)*(V((boop+istep),level,zztop)+V((boop-istep),level,zztop)...
                +V((boop),level+istep,zztop)+V((boop),level-istep,zztop)+V((boop),level,zztop+istep)...
                +V((boop),level,zztop-istep)); %Calculates for x

                Vnew(1:L+1,1,1)=0;%Holds the boundaries constant
                Vnew(1,1:L+1,1)=0;
                Vnew(1,1,1:L+1)=0;
                Vnew(.3*L:.9*L,.5*L,.3*L:.9*L)=-10;
                Vnew(.3*L:.9*L,.7*L,.3*L:.9*L)=10;    
            end;    
        end;
    end;

% if (abs(Vnew(3*L/10-L/10,5*L/10-L/10,3*L/10-L/10)-V(3*L/10-L/10,5*L/10-L/10,3*L/10-L/10))<=.00001)
%     break;
% end;
% boop=(1:L+1); level=(1,(1:L+1)); zztop=(1,1,(1:(L+1)));
boop = 1:L+1;level =1:L+1; zzplot=1:L+1;
V=Vnew;

xslice=L/10+1:L/5:L; yslice=[L/2]; zslice=2*L/10:L/5:L-L/10;
slice(boop,level,zzplot,V,xslice,yslice,zslice);title('Potential graphed in color vs Position Changing over Time.');
view(-13,18);
xlabel=('X-axis');ylabel=('Y-axis');zlabel=('Z-axis'); 
 
drawnow;
mov(moviecounter)=getframe(gcf);
moviecounter=moviecounter+1;
if moviecounter==nstep;
% movie2avi(mov,'BoxPotentialDiffusion')
end;
end;
% movie(Frames,3);



