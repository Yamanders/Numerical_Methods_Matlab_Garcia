% Amanda Molling 11/08/12
%HW 5p Numerical Methods PHYS 3330
%plotWAVEFNS should plot the wavefunctions (even and odd) of a given
%particle in a given potential well at their energy levels


%% plotWAVEFNS.m
% Combine these results in a function that takes m and Vo and plots a
% potential well, with the wavefunctions separated in height by their
% energy.  Be sure to include both the sinusoidal and exponential parts!
%       USAGE:%

function h = plotWAVEFNS(m, L, Vo)
%
%       INPUT:
%       m - mass of the particle (in kg)
%       L - width of the box (in m)
%       Vo - potential of the walls (in eV)
%   
%       OUTPUT:
%       h - figure handle
%
% Test these functions on an electron in a 75eV deep well 0.4 nm across.
preset = 1; %If you want to use different mass and Length and potential, set
%preset 0
clf;
    if preset ==1
    Vo = 75;
    m = 9.11*10^(-31);
    L = .4*10^(-9);
    x = 0:L/70:L-L/70; %This creates an x-array with dimensions equal to my number of energy values.
    end;
    hbar = 4.135667516*10^(-15)
    
    E = energyLEVELS2(9.11*10^-31,.4E-9,75); %This will pull in our E matrix
    
    
    Psi=0;
    index = 1:70;
    for n = 1:70
        k(n) = sqrt(2*m*E(n))/hbar;
        if mod(n,2)==1
            Psi(n) = sin(k(n)*x(n));
    
        else;
            Psi(n) = cos(k(n)*x(n)); 
            
            
        end;
        end
           plot(Psi,E);  
           xlabel('psi')
           ylabel('E')