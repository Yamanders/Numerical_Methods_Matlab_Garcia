% Amanda Molling 11/08/12 Numerical Methods-energyLEVELS
% This function is used to generate the energy levels based on the integer
% n using the solutions derived from the finite potential well problem.




%% energyLEVELS.m
% Write a function that takes m and Vo and computes the energy levels.
%
%       USAGE:
%       E = energyLEVELS(m, L, Vo)
%
%       INPUT:
%       m - mass of the particle (in kg)
%       L - width of the box (in m)
%       Vo - potential of the walls (in eV)
%   
%       OUTPUT:
%       E - 1xn array of energy level values (in eV)

function E = energyLEVELS(m,L,Vo);
m = 9.11E-31;
Vo = 75*1.602*10^(-19);
L = .4*10E-9;
hbar = 4.135667516*10^(-15)*1.602*10^(-19); % eV�s
whos hbar
 b = sqrt(2*m*Vo/hbar^2);
 

% E=zeros(7); n = 1:7
% for n = 1:7;
%     E=-Vo+pi^2*hbar^2*n^2/(2*m*L^2);
% end   
%     plot(n, E);
clc;
alpha = sqrt((2*m*Vo*L*L)/(4*hbar^2))

% ita = @(E) (2*m*E*L^2)/(4*hbar^2);
% k2 = sqrt(2mVo-E)/hbar = a*tan(a*L/2)
% OddFunctionNameIsAnOddName = @(x) -x*(2/L)*cot(x)-sqrt(alpha^2-x^2); 
%For our function, this creates an anonymous function that we can find the
%root of to calculate the intersect.

OddFunctionNameIsAnOddName = @(k) -k*(L/2)*cot(k*L/2)-sqrt(-((k*(L/2))^2)+alpha^2);

EvenFunctionIsOddlyEven = @(k) k*(L/2)*tan(k*L/2)-sqrt(-((k*(L/2))^2)+alpha^2);

% nodd = fsolve(OddFunctionNameIsAnOddName, 6*pi/4) 
% neven = fsolve(EvenFunctionIsOddlyEvens, 6*pi/4)
oddindex = 1
evenindex = 1
for n = 1:70 %Change this to change the number of energies calculated.
% if E-Vo>0;
%   break;
% else;% 
   if mod(n,2)==1 %For odd values of n - use the mod function
         neven = fsolve(EvenFunctionIsOddlyEven, n*pi/4);
        disp('Test line odd E1');
        E(n) = neven^2*hbar/(2*m); %Converts k to E
        oddindex = oddindex + 1;
        
    else;
        disp('Test line for E2'); %%For even values of n 
         nodd = fsolve(OddFunctionNameIsAnOddName, (2*n+1)*pi/8);
         E(n) = nodd^2*hbar/(2*m); %Converts k to E
        evenindex = evenindex +1;
    end;
end;
clc; help energyLEVELS;
disp('This is up to n = 140.');
%This evaluates the intersection

return;
