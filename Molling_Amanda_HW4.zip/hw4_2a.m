%Amanda Molling 10/18/12 HW#4 Question 2
%This is question # 13 on page 120:
%The handwritten forces matrix is on line 16.  

clc; clear all;clf;
help hw4_2a
%% Set equilibrium values:

 nstep=300;
 ktwo=1;
 % Now we plot this whole thing.
   for i=1:nstep;
    kone=i;
    kforces=[kone+ktwo,-ktwo,ktwo,0;kone,-2*kone-ktwo,kone,ktwo;ktwo,kone,-ktwo-2*kone,kone;0,ktwo,kone,-kone-ktwo];
    bForces=-[0;kone;ktwo;+kone+ktwo];
    X=pinv(kforces)*bForces;%Calculates the X at equilibrium (net force =zero)
    Lw=(X(4));
    Xplot(i)=(kone/ktwo);
   end; 
   semilogx(Xplot,Lw,'+')
%    ylim([1.5,4]);
       title('Plot of Spring constant ratios vs. Total length Lw - Hooke');
   ylabel('Length Lw (meters)');
   xlabel('K1/K2')