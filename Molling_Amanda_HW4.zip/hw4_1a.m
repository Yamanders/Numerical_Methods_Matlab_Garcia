%Amanda Molling 10/18/12 HW #4;
%This is question # 11 on page 120:

%%
clc; clear all; help hw4_1a;
testcase = 1;

    if testcase==1;
        kone=0.1; ktwo=0.2; kthree=0.3; kfour=0.4;
        Lone=2; Ltwo=4; Lthree=6; Lfour=8;
    end;     
        
%Now to solve Kx=b;(force=0)

    Krw=[0 0 kfour];
   
%    n = 1:3;
    Kforces=[-kone-ktwo, ktwo, 0; ktwo,-ktwo-kthree, kthree; 0, kthree, -kthree-kfour];
    Lw=Lone+Ltwo+Lthree+Lfour;
    bForces=[-kone*Lone+ktwo*Ltwo; -ktwo*Ltwo+kthree*Lthree; -kthree*Lthree+kfour*(Lfour-Lw)];
    x=inv(Kforces)*bForces;
   disp('X= '); disp(x)
   
 Frw= -kfour*(Lw-x(3)-Lfour) % This is for our picked Lw
 
 nstep=50;
 FrwYPlot=zeros(1,nstep);
 FrwYPlot2=zeros(1,nstep);
 Lnaught=Lone+Ltwo+Lthree+Lfour;
 knaught=inv(inv(kone)+inv(ktwo)+inv(kthree)+inv(kfour));
 % Now we plot this whole thing.
   for i=1:nstep;
    Lw(i)=i;
    %For the hooke's law:
        Kforces=[-kone-ktwo, ktwo, 0; ktwo,-ktwo-kthree, kthree; 0, kthree, -kthree-kfour];
        bForces=[-kone*Lone+ktwo*Ltwo; -ktwo*Ltwo+kthree*Lthree; -kthree*Lthree+kfour*(Lfour-Lw(i))];
        x=inv(Kforces)*bForces;
    FrwYPlot(i)= -kfour*(Lw(i)-x(3)-Lfour);
    FrwYPlot2(i)=-knaught*(Lw(i)-Lnaught);
   end; 
   
   figure(1)=subplot(2,1,1);
    plot(Lw,FrwYPlot, '-');
       title('Plot of Force vs. Total length Lw - Hooke');
   xlabel('Length Lw (meters)');
   ylabel('Force (Newtons)')
%    subplot(1,2,2)=plot(Lw,FrwYPlot,'-')
   figure(2)=subplot(2,1,2);
    plot(Lw,FrwYPlot2,'+')
    
%    )=figure(2); =figure(1);
%    figure(2)=plot();
   title('Plot of Force vs. Total length Lw - Second Equation');
   xlabel('Length Lw (meters)');
   ylabel('Force (Newtons)')
    
    











    
    
    
    
    
   