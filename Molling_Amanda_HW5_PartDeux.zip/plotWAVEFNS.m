% Amanda Molling 11/08/12
%HW 5p Numerical Methods PHYS 3330
%plotWAVEFNS should plot the wavefunctions (even and odd) of a given
%particle in a given potential well at their energy levels


%% plotWAVEFNS.m
% Combine these results in a function that takes m and Vo and plots a
% potential well, with the wavefunctions separated in height by their
% energy.  Be sure to include both the sinusoidal and exponential parts!
%       USAGE:%

% function h = plotWAVEFNS(m, L, Vo)
%
%       INPUT:
%       m - mass of the particle (in kg)
%       L - width of the box (in m)
%       Vo - potential of the walls (in eV)
%   
%       OUTPUT:
%       h - figure handle
%
% Test these functions on an electron in a 75eV deep well 0.4 nm across.
preset = 1; %If you want to use different mass and Length and potential, set
%preset 0
clf;
    if preset ==1
    Vo = 75%*1.602e-019;
    m = 9.11*10^(-31);
    L = 400;
%     x = -1*10^(-9):1*10^(-10):1*10^(-9); %This creates an x-array with dimensions equal to my number of energy values.
    end;
    hbar = 4.135667516*10^(-15)%*1.602e-019;
%     E = energyLEVELS2(9.11*10^-31,.4E-9,75); %This will pull in our E matrix
    Psi=1;

%     E= energyLEVELS(m,L,Vo);
    position=-L:L/100:L;
    E = [1.8, 7.25, 15, 28, 43,64];
A=5;
    for psi = 1:6;    
           n = 1;
           for x=-L:L/100:-L/2; 
               Psi(n)= A*exp(x*sqrt(2*m*E(psi)/(hbar^2)))+(E(psi));
               n =n+1;
           end;
           for x=-L/2+L/100:L/100:L/2; 
               if mod(psi,2)==0
                    Psi(n) = A*sind(sqrt(2*m*E(psi)/(hbar^2))*x)+(E(psi));
               elseif mod(psi,2)==1;
                   Psi(n) = A*cosd(sqrt(2*m*E(psi)/(hbar^2))*x)+(E(psi));
               end;
               n=n+1;
           end;
           for x = L/2+L/100:L/100:L;
              Psi(n)= A*exp(-x*sqrt(2*m*E(psi)/(hbar^2)))+(E(psi)); 
              n=n+1;
           end; 
             if psi==1; Psi1=Psi; end;
             if psi==2; Psi2=Psi; end;
             if psi==3; Psi3=Psi; end;
             if psi==4; Psi4=Psi; end;
             if psi==5; Psi5=Psi; end;
             if psi==6; Psi6=Psi; end;

    end;
disp('hi')
plot(position,Psi1,position,Psi2, position,Psi3, position, Psi4,position,Psi5,position,Psi6);  
xlabel('x')
ylabel('Psi')
% hold;
y1 = -L/2; y2=L/2;
y=0:.1:70;
% plot(y1,y,y2,y)
           
% return;
    