% Amanda Molling 11/08/12 
% Numerical Methods PHYS 3330 
% HW 5 PlotSOLNS outputs a graph of three equations which give solutions
% for the infinite square well potential.
%note: k = k1; a = k2; in my code



%% plotSOLNS.m
% Write a function that takes m, L and Vo as arguments, and plots the three
% functions a/k (k2/k1) (black), tan(kL/2) (blue), -cot(kL/2) (red) as a function 
% of energy ranging from a sufficiently small energy to Vo.  
% Be aware of the scale of the problem, and the fact that a/k goes to 
% infinity at E = 0.
%
%       USAGE:
%       h = plotSOLNS(m, L, Vo)
%
%       INPUT:
%       m - mass of the particle (in kg)
%       L - width of the box (in m)
%       Vo - potential of the walls (in eV)
%   
%       OUTPUT:
%       h - figure handle

% even solns: k tan(k L/2) = a = k1*tan(K1*L/2)= k2
% odd solns:  -1/k tan (k L/2) = 1/a
% where a = sqrt(b^2 - k^2)=k2, k = sqrt(2mE/hbar^2) =k1, b = sqrt(2mVo/hbar^2)
 

function h =  PlotSOLNS(m,L,Vo);
clc; close all; help PlotSOLNS;
hbar = 0.658211928E-15*1.602*10^(-19); % eV�s


preset = 1; %If you want to use different mass and Length and potential, set
%preset = 0
    if preset ==1
    Vo = 75*1.602*10^(-19);
    m = 9.11*10^(-31);
    L = .4*10^(-9);
    end;
Plotratio = 0; % Turn these on to allocate for speed, I prefered
% not too, because you have to set these equal to the maxindex
Tan =0;
Cot=0;


Vo=abs(Vo);
E = 0.01*Vo:0.005*Vo:Vo;%eV 
% This creates an index of energies that will always be proportional to the
% potential.
%I start my index at 1 to eliminate the E = 0 problem. 
maxindex = 1/.005-19; %maxindex to make the vectors agree in number
% for n = 1:maxindex;
for n = 1:199;
 k(n) = (sqrt(2*m*E(n)/hbar^2));
 b = sqrt(2*m*Vo/hbar^2);
 a(n) = sqrt(b^2 - (k(n))^2);
% a(n) = sqrt((2*m*(Vo-E(n)))/hbar);

Plotratio(n) = a(n)/k(n);
Tan(n) = tan(k(n)*L/2);
Cot(n) = -cot(k(n)*L/2);
end;

%This is all for the first plot
h= figure(1);
% subplot(2,2,1);
plot(E,Plotratio, '-k', E, Tan, '-b', E, Cot, '-r')
axis([0,Inf, 0, 7])
xlabel('Energy division up to Vo')
ylabel('(Vo-E)/E or k2/k1');
title('Graph of k2/k1 and its Solutions for the Finite Potential Well');

grid on;
%{
%This is for the second plot (even)
subplot(2,2,2);
plot(E, Tan,'-.b'); axis([0,Inf, -10, 10])
xlabel('Energy division up to Vo')
ylabel('(Vo-E)/E or k2/k1');
title('Graph of tangent(k*L/2) and its Solutions for the Finite Potential Well');
grid on;

% This is for the third plot (odd)
subplot(2,2,3);
plot(E, Cot,'-.r');axis([0,Inf, -10, 10])
xlabel('Energy division up to Vo')
ylabel('(Vo-E)/E or k2/k1');
% title('Graph of k2/k1 and its Solutions for the Finite Potential Well');
grid on;
%Plot each on the same graph with the required colors.
% set(h,'Color', 'black');
% legend('a/k', 'Tan(k*L/2)','- Cot(k*L/2)');
xlabel('Energy division up to Vo')
ylabel('Odd Solution of -cot(k1*L/2');
% title('Graph of k2/k1 and its Solutions for the Finite Potential Well');
%}

end
