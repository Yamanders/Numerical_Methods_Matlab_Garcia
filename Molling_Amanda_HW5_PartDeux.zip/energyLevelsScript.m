m = 9.11E-31;
Vo = 75%*1.602e-019;
L = .4*10E-9;
hbar = 4.135667516*10^(-15)%*1.602*10^(-19);% eV�s
% hbar = 6.626e-034
 b = sqrt(2*m*Vo/hbar^2);
 clc

% E=zeros(7); n = 1:7
% for n = 1:7;
%     E=-Vo+pi^2*hbar^2*n^2/(2*m*L^2);
% end   
%     plot(n, E);

% alpha = sqrt((2*m*Vo*L*L)/(4*hbar^2))

% ita = @(E) (2*m*E*L^2)/(4*hbar^2);
% k2 = sqrt(2mVo-E)/hbar = a*tan(a*L/2)
% OddFunctionNameIsAnOddName = @(x) -x*(2/L)*cot(x)-sqrt(alpha^2-x^2); 
%For our function, this creates an anonymous function that we can find the
%root of to calculate the intersect.

% OddFunctionNameIsAnOddName = @(k) -k*(L/2)*cot(k*L/2)-sqrt(-((k*(L/2))^2)+alpha^2);

% EvenFunctionIsOddlyEven = @(k) k*(L/2)*tan(k*L/2)-sqrt(-((k*(L/2))^2)+alpha^2);
% OddFunctionNameIsAnOddName = @(E) -cot(sqrt(2*m*E/(hbar^2))*(L/2))-sqrt(b^2-(2*m*E/(hbar)^2));
% EvenFunctionIsOddlyEven = @(E) tan(sqrt(2*m*E/(hbar^2))*(L/2))-sqrt(b^2-(2*m*E/(hbar^2)));
OddFunctionNameIsAnOddName = @(E) -sqrt(2*m*E)*cot(sqrt(2*m*E)*(L/2)/hbar)/hbar-sqrt(b^2-(2*m*E/(hbar^2)));
EvenFunctionIsOddlyEven = @(E) sqrt(2*m*E)*tan(sqrt(2*m*E)*(L/2)/hbar)/hbar-sqrt(b^2-(2*m*E/(hbar^2)));

neven = 0; nodd =0;
% E = 0;
for n = 1:6 %Change this to change the number of energies calculated.
% if E-Vo>0;
%   break;
% else;% 
 %For odd values of n - use the mod function
       if n == 1;  
           neven(n) = fsolve(EvenFunctionIsOddlyEven, 1.8);%(.03e-017)/(1.602e-019))%)1.8; end
       end;
       if n == 3;
           neven(n) = fsolve(EvenFunctionIsOddlyEven, 15);%(.25e-017)/(1.602e-019))%15); 
       end;
       if n == 5;
           neven(n) = fsolve(EvenFunctionIsOddlyEven, 43);%(.68e-017)/(1.602e-019)) %43); 
       end;
       
       
%         oddindex = oddindex + 1;
        
        if n == 2
            nodd(n) = fsolve(OddFunctionNameIsAnOddName, 7.25);%(.1e-017)/(1.602e-019)) %7.25); 
        end;
        if n==4
            nodd(n) = fsolve(OddFunctionNameIsAnOddName, 28);%(.45e-017)/(1.602e-019)) %28); 
        end;
        if n==6
            nodd(n) = fsolve(OddFunctionNameIsAnOddName, 62);%(1e-017)/(1.602e-019))% 62); 
        end; 
        E(n) = (neven(n))%./(1.602e-019); %Converts E to EV
         E(n) = (nodd(n)); %Converts k to E
%         evenindex = evenindex +1;

end;
%This evaluates the intersection
E=E
return;
